package PaymentTypes;

public interface PaymentType {

	float getPrice();

}
