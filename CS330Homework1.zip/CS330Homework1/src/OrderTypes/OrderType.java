package OrderTypes;

public abstract interface OrderType {
	public void printOrder();
}
